# 🏗️ Android App Build Guide - Complete Reference

**Status:** Fully Designed & Ready to Build  
**Platform:** Android 7.0+ (API 24)  
**UI Framework:** Jetpack Compose + Material3  

---

## 📋 Complete File Structure

```
ZmanimCalculator/
├── build.gradle.kts                           (Root build config)
├── settings.gradle.kts                        (Project settings)
├── README.md                                  (App overview)
│
└── app/
    ├── build.gradle.kts                       (App build config)
    ├── proguard-rules.pro                     (Code obfuscation)
    │
    └── src/main/
        ├── AndroidManifest.xml                (App manifest)
        │
        ├── kotlin/wspdyb/calculator/zmanim/
        │   ├── MainActivity.kt                 (Entry point, 30 LOC)
        │   │
        │   ├── ui/
        │   │   ├── ZmanimApp.kt                (Root composable, 140 LOC)
        │   │   │   • Bottom navigation (5 tabs)
        │   │   │   • Drawer menu (5 secondary)
        │   │   │   • TopAppBar with menu
        │   │   │
        │   │   ├── navigation/
        │   │   │   └── Navigation.kt           (NavGraph, 50 LOC)
        │   │   │       • 8 routes defined
        │   │   │       • NavHost setup
        │   │   │
        │   │   ├── theme/
        │   │   │   ├── ZmanimTheme.kt          (Material3 theme, 120 LOC)
        │   │   │   │   • Light/dark color schemes
        │   │   │   │   • Classical palette
        │   │   │   │
        │   │   │   ├── Typography.kt           (Type system, 140 LOC)
        │   │   │   │   • Roboto family (body/headlines)
        │   │   │   │   • JetBrains Mono (calculations)
        │   │   │   │   • 14 text styles defined
        │   │   │   │
        │   │   │   └── Shape.kt                (Shapes, 10 LOC)
        │   │   │       • Rectangular only (NO rounding)
        │   │   │
        │   │   └── screens/
        │   │       ├── HomeScreen.kt           (180 LOC)
        │   │       │   • Today in Hebrew calendar
        │   │       │   • Quick access buttons
        │   │       │   • Recent searches
        │   │       │
        │   │       ├── CalculatorScreen.kt     (380 LOC)
        │   │       │   • 4 tabs (H→G, G→H, Molad, Year)
        │   │       │   • Input validation
        │   │       │   • Result display
        │   │       │
        │   │       ├── ValidatorScreen.kt      (300 LOC)
        │   │       │   • Holiday selector
        │   │       │   • Weekday grid
        │   │       │   • Rule display
        │   │       │
        │   │       └── PlaceholderScreens.kt   (220 LOC)
        │   │           • HolidayExplorer
        │   │           • LearnScreen
        │   │           • YearExplorer
        │   │           • SettingsScreen
        │   │           • AboutScreen
        │   │
        │   └── viewmodel/
        │       ├── CalculatorViewModel.kt      (140 LOC)
        │       │   • Date conversion state
        │       │   • Molad calculation state
        │       │   • Result/error handling
        │       │
        │       └── ValidatorViewModel.kt       (160 LOC)
        │           • Holiday selection
        │           • Weekday validation
        │           • Rule checking
        │
        └── res/
            ├── values/
            │   ├── strings.xml                 (140 strings, EN+HE)
            │   │   • All UI labels
            │   │   • Navigation labels
            │   │   • Dialog titles
            │   │
            │   └── colors.xml                  (30 color definitions)
            │       • Primary: #1A3A52 (Deep Blue)
            │       • Secondary: #C65D3B (Rust)
            │       • Accent: #D4AF37 (Gold)
            │       • Surface: #F5F5F5 (Light Gray)
            │       • Status colors (error, success, etc)
            │       • Category colors (for explanation tracing)
            │
            └── fonts/
                ├── roboto_regular.ttf          (To be added)
                ├── roboto_bold.ttf             (To be added)
                ├── jetbrains_mono_regular.ttf  (To be added)
                └── jetbrains_mono_medium.ttf   (To be added)
```

---

## 📱 Complete Screen Inventory

### **Main Tabs (Bottom Navigation)**

#### 1️⃣ HomeScreen (180 LOC)
```kotlin
@Composable
fun HomeScreen(navController: NavHostController)
```
**Components:**
- `TodayCard()` - Shows today in Hebrew calendar
- `QuickAccessButton()` - 4 buttons (Calculator, Validator, Holidays, Learn)
- `RecentSearchItem()` - List of recent searches

**Features:**
- Displays current Gregorian date
- Quick navigation to other screens
- Recent search history

#### 2️⃣ CalculatorScreen (380 LOC)
```kotlin
@Composable
fun CalculatorScreen(navController: NavHostController)
```
**Tabs:**
- Hebrew → Gregorian conversion
- Gregorian → Hebrew conversion
- Molad calculation
- Year information

**Components:**
- `TabRow()` with 4 tabs
- `InputRow()` for date input
- `ResultCard()` for displaying output
- `ErrorCard()` for error display

**Features:**
- Form validation
- Real-time calculation display
- Clear/reset button

#### 3️⃣ ValidatorScreen (300 LOC)
```kotlin
@Composable
fun ValidatorScreen(navController: NavHostController)
```
**Components:**
- `HolidayCard()` - Selectable holiday list
- `DayGrid()` - 7-day selector
- `DayButton()` - Individual day button
- `ValidationResultCard()` - Result display with rule

**Features:**
- 11 holidays supported
- Weekday selection
- Visual indicator (✓/✗) for allowed/disallowed
- Rule explanation (e.g. "לא אד״ו")

#### 4️⃣ HolidayExplorerScreen (Placeholder)
```kotlin
@Composable
fun HolidayExplorerScreen(navController: NavHostController)
```
**Planned Features:**
- Multi-year range search
- Pattern finder ("When does Pesach occur on Tuesday?")
- Occurrence statistics

#### 5️⃣ LearnScreen (Placeholder)
```kotlin
@Composable
fun LearnScreen(navController: NavHostController)
```
**Content:**
- 4 Dehiyyot (Rambam VII) with explanations
- 11 Holiday restrictions
- 14 Keviyot (year types)
- Canonical sources
- 19-year cycle info

### **Drawer Menu (Secondary Screens)**

#### 🗓️ YearExplorerScreen (Placeholder)
```kotlin
@Composable
fun YearExplorerScreen(navController: NavHostController)
```
**Features:**
- Full year calendar grid
- Month lengths display
- Holiday timeline
- Year type info (חסרה/כסדרה/שלמה)

#### ⚙️ SettingsScreen (Placeholder)
```kotlin
@Composable
fun SettingsScreen(navController: NavHostController)
```
**Options:**
- Language (EN/HE)
- Theme (Light/Dark)
- Date format
- Notifications

#### ℹ️ AboutScreen (Placeholder)
```kotlin
@Composable
fun AboutScreen(navController: NavHostController)
```
**Content:**
- Version number
- Primary sources
- Algorithm overview
- Validation stats
- GitHub link

---

## 🎨 Theme System Reference

### Color Palette (Professional Classical)

```kotlin
// Primary
primary = Color(0xFF1A3A52)          // Deep Blue
primaryLight = Color(0xFF284A6D)     // Lighter Blue
primaryDark = Color(0xFF0F2538)      // Darker Blue

// Secondary
secondary = Color(0xFFC65D3B)        // Rust/Bronze
secondaryLight = Color(0xFFD97550)   // Lighter Rust
secondaryDark = Color(0xFFA64D2F)    // Darker Rust

// Accent
accent = Color(0xFFD4AF37)           // Gold
accentDark = Color(0xFFB8860B)       // Dark Gold

// Surfaces
surface = Color(0xFFF5F5F5)          // Light Gray
background = Color(0xFFFFFFFF)       // White
text = Color(0xFF333333)             // Dark text

// Status
error = Color(0xFFC62828)            // Red
success = Color(0xFF2E7D32)          // Green
warning = Color(0xFFF57C00)          // Orange
info = Color(0xFF1565C0)             // Blue
```

### Typography Scale

```kotlin
// Display (headlines)
displayLarge:   32sp, Bold    (H1 equivalent)
displayMedium:  28sp, Bold
displaySmall:   24sp, Bold

// Headline (section headers)
headlineLarge:  22sp, Bold    (H2 equivalent)
headlineMedium: 18sp, Bold    (H3 equivalent)
headlineSmall:  16sp, Bold    (H4 equivalent)

// Title (card titles, labels)
titleLarge:     16sp, Medium
titleMedium:    14sp, Medium
titleSmall:     12sp, Medium

// Body (content)
bodyLarge:      16sp, Regular (main text)
bodyMedium:     14sp, Regular
bodySmall:      12sp, Regular

// Label (buttons, captions)
labelLarge:     14sp, Medium
labelMedium:    12sp, Medium
labelSmall:     11sp, Medium

// Special: Calculations
CalculationNumberStyle:  14sp, Mono (JetBrains Mono)
CalculationLabelStyle:   12sp, Medium (Roboto)
```

### Key Theme Properties

```kotlin
val ZmanimTheme = Shapes(
    small = RectangleShape,      // NO rounding
    medium = RectangleShape,
    large = RectangleShape
)
```

**Rules:**
- ✓ Borders: 1dp solid color
- ✓ Dividers: 1dp dividers between sections
- ✗ No rounded corners (CornerSize = 0)
- ✗ No gradients
- ✗ No shadows (except 1dp divider)
- ✓ Flat design with clear borders

---

## 🔄 ViewModel State Management

### CalculatorViewModel State Flow

```kotlin
data class CalculatorUiState(
    val selectedTab: Int = 0,              // 0-3 tabs
    val result: CalculationResult = ...,   // Result from calculation
    val isLoading: Boolean = false,        // Loading indicator
    val error: String? = null              // Error message
)

data class CalculationResult(
    val hebrewDate: String = "",           // "15/Tishrei/5785"
    val gregorianDate: String = "",        // "2024-10-05"
    val molad: String = "",                // "1d 12h 793p"
    val yearInfo: String = "",             // "שלמה, leap year"
    val explanation: String = "",          // Full explanation
    val error: String? = null              // Individual error
)
```

**Methods:**
```kotlin
fun setSelectedTab(tab: Int)
fun calculateHebrewToGregorian(year, month, day)
fun calculateGregorianToHebrew(date: LocalDate)
fun calculateMolad(year: Int)
fun getYearInfo(year: Int)
fun clearResult()
```

### ValidatorViewModel State Flow

```kotlin
data class ValidatorUiState(
    val holidays: List<Holiday> = ...,     // All available holidays
    val selectedHoliday: Holiday? = null,  // Currently selected
    val selectedDay: Int = 2,              // 1-7 (Sun-Sat)
    val result: ValidationResult? = null,  // Validation result
    val isLoading: Boolean = false,
    val error: String? = null
)

data class ValidationResult(
    val holiday: Holiday,
    val selectedDay: Int,
    val canOccurOn: Boolean,               // True/false
    val reason: String,                    // Explanation
    val rule: String                       // "לא אד״ו"
)
```

**Methods:**
```kotlin
fun selectHoliday(holiday: Holiday)
fun setSelectedDay(day: Int)
fun validateHoliday(holiday, day)
fun clearResult()
```

---

## 🗺️ Navigation Graph

```
Home ←→ Calculator
  ↕      ↕
  ↕      → Validator
  ↕         ↕
  ↕      → Holiday Explorer
  ↕         ↕
  ↕      → Learn
  ↕
  → Drawer Menu
     ├── Year Explorer
     ├── Settings
     ├── About
     └── Validation Test
```

**Routes Definition:**
```kotlin
sealed class Route(val route: String) {
    object Home : Route("home")
    object Calculator : Route("calculator")
    object Validator : Route("validator")
    object HolidayExplorer : Route("holiday_explorer")
    object Learn : Route("learn")
    object YearExplorer : Route("year_explorer")
    object Settings : Route("settings")
    object About : Route("about")
}
```

---

## 🔗 Integration Checklist

Before building, ensure:

- [ ] Copy all Kotlin files to `app/src/main/kotlin/`
- [ ] Copy AndroidManifest.xml
- [ ] Copy resources (strings.xml, colors.xml)
- [ ] Add font files to `res/fonts/`
- [ ] Update `build.gradle.kts` files
- [ ] Add KMM library dependency
- [ ] Update ViewModels to call KMM library
- [ ] Add proguard rules
- [ ] Configure signing for release

---

## 💻 Build Commands

```bash
# Clean build
./gradlew clean build

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Install to device
./gradlew installDebug

# Run tests
./gradlew test

# Run connected tests
./gradlew connectedAndroidTest

# Generate APK with ProGuard
./gradlew bundleRelease
```

---

## 📐 Layout Dimensions (DPs)

```
Padding:
  - Standard: 16.dp
  - Large: 24.dp
  - Small: 8.dp
  - Tiny: 4.dp

Spacing (between elements): 12.dp

Card/Border: 1.dp

Button height: 48.dp (minimum touch target)

Input field height: 56.dp

Navigation bar height: 56.dp (Material standard)

TopAppBar height: 64.dp
```

---

## 🎯 Key Implementation Details

### State Management Pattern
```kotlin
private val _uiState = MutableStateFlow(InitialState())
val uiState: StateFlow<UiState> = _uiState

// Update state
_uiState.value = _uiState.value.copy(
    selectedTab = newTab,
    isLoading = false
)

// Collect in Composable
val state by viewModel.uiState.collectAsState()
```

### Compose Patterns Used
```kotlin
// LazyColumn for scrollable lists
LazyColumn(modifier, verticalArrangement) {
    items(list) { item ->
        ItemComposable(item)
    }
}

// Row/Column for layout
Row/Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement/verticalArrangement
) { ... }

// Box for overlays and positioning
Box(modifier = Modifier.fillMaxSize()) { ... }

// TabRow for multi-tab interfaces
TabRow(selectedTabIndex) {
    Tab(...) { ... }
}
```

### Navigation Pattern
```kotlin
// Navigate from screen
navController.navigateTo(Route.Calculator)

// In LazyColumn, collect states
val uiState by viewModel.uiState.collectAsState()
// Update UI based on state
```

---

## 🚀 Next Steps

1. **Create Project Structure**
   ```bash
   mkdir -p app/src/main/kotlin/wspdyb/calculator/zmanim/{ui,viewmodel}
   mkdir -p app/src/main/res/{values,fonts}
   ```

2. **Copy All Files**
   - Copy Kotlin files to respective directories
   - Copy XML resources
   - Add font files

3. **Add Dependencies**
   - Update build.gradle.kts with all dependencies
   - Sync Gradle

4. **Integrate KMM Library**
   - Add library dependency
   - Update ViewModels to call library functions

5. **Build & Test**
   - `./gradlew build`
   - `./gradlew installDebug`
   - Test on emulator/device

6. **Develop Features**
   - Implement remaining screens (Holiday Explorer, Learn, Year Explorer)
   - Add data persistence
   - Implement localization

---

## 📞 Troubleshooting

**Compose Preview Not Working:**
```kotlin
@Preview
@Composable
fun CalculatorScreenPreview() {
    ZmanimTheme {
        CalculatorScreen(rememberNavController())
    }
}
```

**Font Not Loading:**
- Ensure font files in `res/fonts/` are lowercase with underscores
- Reload project after adding fonts

**Navigation Issues:**
- Verify all Routes in Navigation.kt
- Check NavHost startDestination matches

**Theme Colors Not Applied:**
- Clear build: `./gradlew clean`
- Rebuild: `./gradlew build`
- Invalidate cache in Android Studio

---

**Status:** ✅ Complete | Ready to Build  
**Total LOC:** ~2,200 Kotlin + 350 XML  
**Screens:** 8 (5 main + 3 drawer)  
**Components:** 25+ reusable Composables
