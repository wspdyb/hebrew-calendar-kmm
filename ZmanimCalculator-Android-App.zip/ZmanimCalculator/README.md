# זמנים קלקולטור - Zmanim Calculator Android App

Professional Hebrew calendar calculator for Android built with Jetpack Compose, integrating the Kotlin Multiplatform Hebrew Calendar Engine.

**Status:** UI/UX Complete | Ready for KMM Library Integration

---

## 📋 Project Overview

This is a complete Android application for Hebrew calendar calculations, featuring:

- **Date Conversion:** Hebrew ↔ Gregorian
- **Molad Calculation:** Lunar conjunction (חישוב מולד)
- **Holiday Validator:** Rules-based weekday restrictions
- **Year Explorer:** Full year calendars with holidays
- **Educational Content:** Learn about Rambam's rules, dehiyyot, keviyot

### Architecture

```
app/src/main/kotlin/wspdyb/calculator/zmanim/
├── MainActivity.kt                  (Entry point)
├── ui/
│   ├── ZmanimApp.kt                (Root composable with nav)
│   ├── screens/                    (5 main + 3 secondary screens)
│   │   ├── HomeScreen.kt
│   │   ├── CalculatorScreen.kt
│   │   ├── ValidatorScreen.kt
│   │   ├── PlaceholderScreens.kt   (Holiday, Learn, Year, Settings, About)
│   ├── navigation/
│   │   └── Navigation.kt           (NavGraph and routing)
│   └── theme/
│       ├── ZmanimTheme.kt          (Material3 theme)
│       ├── Typography.kt           (Roboto + JetBrains Mono)
│       └── Shape.kt                (Rectangular, no rounding)
├── viewmodel/
│   ├── CalculatorViewModel.kt
│   └── ValidatorViewModel.kt
└── resources/
    ├── values/
    │   ├── strings.xml             (UI text, EN+HE)
    │   └── colors.xml              (Professional palette)
    └── fonts/                       (Roboto, JetBrains Mono)
```

---

## 🎨 Design System

### Classical Professional Palette
```
Primary:      #1A3A52  (Deep Blue)
Secondary:    #C65D3B  (Rust/Bronze)
Accent:       #D4AF37  (Gold)
Surface:      #F5F5F5  (Light Gray)
Text:         #333333  (Dark)
```

### Typography
- **Headlines:** Roboto Bold (22-32sp)
- **Body:** Roboto Regular (14-16sp)
- **Calculations:** JetBrains Mono (14sp monospace)

### Layout Principles
✓ Rectangular cards (NO rounded corners)
✓ No gradients (flat design)
✓ 1dp dividers only (minimal shadows)
✓ Clear hierarchy with borders, not decoration

---

## 📱 Screen Structure

### Bottom Navigation (5 Main Tabs)

1. **🏠 Home** - Quick access, recent searches, today in Hebrew calendar
2. **🧮 Calculator** - 4-tab interface for conversions and calculations
   - Hebrew → Gregorian
   - Gregorian → Hebrew
   - Molad (lunar conjunction)
   - Year Information
3. **🔎 Validator** - Holiday restrictions checker
   - Select holiday (11 options)
   - Choose weekday
   - See if combination is allowed + rule
4. **📅 Holiday Explorer** - Multi-year pattern finder
   - Search across years
   - Find patterns
5. **📖 Learn** - Educational guide
   - 4 Dehiyyot explained
   - 11 Restrictions
   - 14 Keviyot
   - Canonical sources

### Drawer Menu (Secondary Options)

- 🗓️ Year Explorer - Full year calendar grid
- 🔢 Cycles & Rules - 19-year cycle, keviyot table
- 🧪 Validation Test - Run 10,000-year integrity check
- ⚙️ Settings - Language, theme, format
- ℹ️ About - Version, sources, GitHub link

---

## 🔧 Setup & Build

### Prerequisites

- **Android Studio** 2023.1+
- **JDK 11+**
- **Gradle 8.0+**

### Clone & Setup

```bash
cd ZmanimCalculator
./gradlew clean
./gradlew build
```

### Run on Emulator/Device

```bash
./gradlew installDebug
./gradlew connectedAndroidTest
```

### Build Release APK

```bash
./gradlew bundleRelease
# or
./gradlew assembleRelease
```

**Output:** `app/build/outputs/apk/release/app-release.apk`

---

## 📚 Integration with KMM Library

The app is **ready to integrate** the Kotlin Multiplatform Hebrew Calendar Engine.

### Current Status

✅ **UI/UX Complete**
- All screens designed
- Navigation wired
- ViewModels structured
- Theme system in place

⏳ **Next: Library Integration**

### How to Integrate

1. **Add KMM Library as Dependency**

   In `app/build.gradle.kts`:
   ```kotlin
   dependencies {
       // Hebrew Calendar KMM Library
       implementation(project(":hebrew-calendar-kmm:shared"))
       // or
       implementation("com.wspdyb.zmanim:hebrew-calendar-kmm:1.0.0")
   }
   ```

2. **Import and Use in ViewModels**

   ```kotlin
   import wspdyb.calculator.zmanim.HebrewCalendarEngine
   import wspdyb.calculator.zmanim.TraceableHebrewCalendarEngine
   import wspdyb.calculator.zmanim.ExplanationEngine

   class CalculatorViewModel : ViewModel() {
       fun calculateHebrewToGregorian(year: Int, month: Int, day: Int) {
           val (yearCalc, trace) = TraceableHebrewCalendarEngine.calculateYearWithTrace(year)
           val explanation = ExplanationEngine.explainYear(trace, "en")
           // Update UI state with results
       }
   }
   ```

3. **Use RuleValidator for Holiday Checks**

   ```kotlin
   import wspdyb.calculator.zmanim.RuleValidator

   class ValidatorViewModel : ViewModel() {
       fun validateHoliday(holidayId: String, weekday: Int) {
           val result = RuleValidator.validateDateRestriction(holidayId, weekday)
           // Update UI with validation result
       }
   }
   ```

---

## 📊 Data Models

### CalculationResult
```kotlin
data class CalculationResult(
    val hebrewDate: String,
    val gregorianDate: String,
    val molad: String,
    val yearInfo: String,
    val explanation: String,
    val error: String? = null
)
```

### ValidationResult
```kotlin
data class ValidationResult(
    val holiday: Holiday,
    val selectedDay: Int,
    val canOccurOn: Boolean,
    val reason: String,
    val rule: String  // e.g. "לא אד״ו"
)
```

---

## 🌍 Localization

Currently set up for:
- **English (en)** - Default
- **Hebrew (he)** - Right-to-left support

### Adding New Language

1. Create `values-xx/strings.xml`
2. Translate all `<string>` elements
3. Update `CalculatorViewModel` and `ExplanationEngine` to support language

---

## 🧪 Testing

```bash
# Run unit tests
./gradlew test

# Run Android tests (on emulator/device)
./gradlew connectedAndroidTest

# Run with coverage
./gradlew testDebugUnitTestCoverage
```

---

## 📦 Dependencies

**Core**
- `androidx.core:core-ktx:1.12.0`
- `androidx.lifecycle:lifecycle-runtime-ktx:2.6.2`
- `androidx.activity:activity-compose:1.8.1`

**Jetpack Compose**
- `androidx.compose.ui:ui:2023.10.01`
- `androidx.compose.material3:material3:1.1.2`
- `androidx.compose.foundation:foundation:1.5.4`

**Navigation**
- `androidx.navigation:navigation-compose:2.7.5`

**Data Persistence**
- `androidx.datastore:datastore-preferences:1.0.0`

**Serialization**
- `org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0`

See `app/build.gradle.kts` for full list.

---

## 🚀 Deployment

### Google Play Store

1. Create Google Play Developer account ($25 one-time fee)
2. Build release APK/Bundle
3. Sign with upload key
4. Create app listing
5. Upload bundle
6. Fill out store listing
7. Submit for review

### Direct APK Distribution

1. Build release APK: `./gradlew assembleRelease`
2. Host on your server
3. Share link with users
4. Users enable "Unknown Sources" to install

---

## 📝 License

This project is open source. Licensed under MIT.

---

## 🔗 Links

- **GitHub:** https://github.com/wspdyb/hebrew-calendar-kmm
- **KMM Library:** [hebrew-calendar-kmm README](../hebrew-calendar-kmm/README.md)
- **Rambam Source:** Hilchot Kiddush HaChodesh VI-VII
- **Talmud:** Rosh Hashanah 20a, Sukkah 43b, Megillah 5a

---

## 👨‍💻 Development

### Project Structure

- **UI Layer:** Compose-based screens with Material3
- **ViewModel Layer:** State management with StateFlow
- **Business Logic:** KMM shared library (Hebrew Calendar Engine)
- **Data Layer:** DataStore preferences, local calculations

### Adding a New Screen

1. Create `MyScreen.kt` in `ui/screens/`
2. Define data class in corresponding ViewModel
3. Add route in `Navigation.kt`
4. Add to `AppNavHost` composable
5. Wire navigation button

### Styling Guidelines

- Use theme colors from `ZmanimTheme`
- Text styles from `ZmanimTypography`
- Shapes from `ZmanimShapes` (rectangles only)
- Max width for body text: 75 characters
- Padding: multiples of 4dp, 8dp, 12dp, 16dp

---

## 📞 Support

For issues, feature requests, or questions:
1. Check GitHub Issues
2. Create new issue with details
3. Include: device, Android version, steps to reproduce

---

## ✨ Next Steps

- [ ] Integrate KMM Library
- [ ] Implement all ViewModels with real calculations
- [ ] Add unit tests
- [ ] Implement DataStore preferences
- [ ] Add RTL support for Hebrew
- [ ] Create app icon and branding
- [ ] Beta testing
- [ ] Play Store release

---

**Version:** 1.0.0  
**Last Updated:** October 2026  
**Status:** UI Complete, Ready for Integration
